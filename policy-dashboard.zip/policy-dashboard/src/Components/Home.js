import React from "react"
import LoginForm from "../Components/Login/LoginForm";
const Home = () => {
  return <LoginForm />;
};
export default Home;
