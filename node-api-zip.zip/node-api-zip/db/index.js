const MongoClient = require('mongodb').MongoClient;
const keys = require('../config');
var ObjectId = require('mongodb').ObjectID;

//DB Config
const dbUri = keys.MongoUri;

let dbo = null;

const init = async () => {
    try {
        MongoClient.connect(dbUri, { useNewUrlParser: true, useUnifiedTopology: true }, (err, db) => {
            if (err) {
                throw err
            } else {
                console.log('Mongo db connected')
                dbo = db.db(keys.dbName)
            }
        });
    } catch (err) {
        console.log('Error while initializing mongodb')
    }
}

const findAll = async () => {
    try {
        const result = await dbo.collection(keys.collectionName).find({}).toArray()
        return result
    } catch (err) {
        throw err
    }
}

// const findOne = async (_id) => {
//     try {
//         const result = await dbo.collection(keys.collectionName).findOne({ "_id": new ObjectId(_id) })
//         return result
//     } catch (err) {
//         throw err
//     }
// }

const addPolicy = async (policy) => {
    try {
        const result = await dbo.collection(keys.collectionName).insertOne(policy)
        return result
    } catch (err) {
        throw err
    }
}

// const updatePolicy = async (policy) => {
//     try {
//         var myQuery = { "_id": new ObjectId(policy._id) };
//         var newValues = { $set: { "customerName": policy.customerName, "address": book.address, "policyNumber": book.policyNumber } };
//         const result = await dbo.collection(keys.collectionName).updateOne(myQuery, newValues);
//         return result
//     } catch (err) {
//         throw err
//     }
// }

// const deletePolicy = async (_id) => {
//     try {
//         var myQuery = { "_id": new ObjectId(_id) };
//         const result = await dbo.collection(keys.collectionName).deleteOne(myQuery)
//         return result
//     } catch (err) {
//         throw err
//     }
// }

module.exports = { init, findAll, addPolicy };