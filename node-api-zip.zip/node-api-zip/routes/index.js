const express = require('express')
const router = express.Router()
const controller = require('../controller')

router.get('/', (req, res) => {
    res.send('Welcome to Policy Dashboard')
})

router.get('/policies', async (req, res) => {
    const data = await controller.getAll()
    res.send(data)
})


router.post('/addpolicy', async (req, res) => {
    const newPolicy = {
        customerName: req.body.customerName,
        address: req.body.address,
        policyNumber: req.body.policyNumber
    }
    await controller.addPolicy(newPolicy)
    res.send('Policy Created successfully!!')
})

// router.put('/updatepolicy', (req, res) => {
//     const newPolicy = {
//         _id: req.body._id,
//         customerName: req.body.customerName,
//         address: req.body.address,
//         policyNumber: req.body.policyNumber
//     }

//     controller.updatePolicy(newPolicy)
//     res.send('Policy Updated successfully!!')
// })

// router.delete('/deletepolicy', (req, res) => {
//     let _id = req.body._id
//     controller.deletePolicy(_id)
//     res.send('Policy Deleted!!')
// })

module.exports = router