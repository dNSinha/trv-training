module.exports = {
    MongoUri: 'mongodb://localhost:27017/',
    dbName: 'PolicyDetails',
    collectionName: 'policy'
}