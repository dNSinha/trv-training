const policyDS = require('../db')

const getAll = () => {
    const policy = policyDS.findAll();
    return policy
}

const addPolicy = (policy) => {
    const newPolicy = policyDS.addPolicy(policy);
    return newPolicy
}

module.exports = { getAll, addPolicy }