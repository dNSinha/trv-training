const express = require('express')
const bodyParser = require('body-parser')
const route = require('./routes')
const policyDS = require('./db')

const app = express()
const port = 3000

policyDS.init()
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use('/api', route)

app.listen(port, function () {
    console.log('Running on port', port);
})